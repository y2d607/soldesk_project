<���̺� ����> -- 20��

drop table pro_profile;
drop table career;
drop table education;
drop table portfolio;
drop table servicectg;
drop table detailctg;
drop table review;
drop table received_quote;
drop table interests;
drop table status;
drop table board;
drop table report;
drop table comments;
drop table forbiddenWords;
drop table chatroom;
drop table chatHistory;
drop table admin;
drop table calendar;
drop table pro_user;
drop table users;


<������ ����> -- 19��
DROP SEQUENCE user_seq;
DROP SEQUENCE pro_seq;
DROP SEQUENCE pro_profile_seq;
DROP SEQUENCE career_seq;
DROP SEQUENCE education_seq;
DROP SEQUENCE portfolio_seq;
DROP SEQUENCE servicectg_seq;
DROP SEQUENCE detailctg_seq;
DROP SEQUENCE review_seq;
DROP SEQUENCE received_quote_seq;
DROP SEQUENCE interests_seq;
DROP SEQUENCE status_seq;
DROP SEQUENCE board_seq;
DROP SEQUENCE report_seq;
DROP SEQUENCE comments_seq;
DROP SEQUENCE forbiddenWords_seq;
DROP SEQUENCE chatroom_seq;
DROP SEQUENCE chatHistory_seq;
DROP SEQUENCE calendar_seq;