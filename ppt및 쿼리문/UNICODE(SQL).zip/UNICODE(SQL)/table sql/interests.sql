--------------------------------------------------------
--  ������ ������ - ������-2��-21-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table INTERESTS
--------------------------------------------------------

  CREATE TABLE "MD_UNIQUE"."INTERESTS" 
   (	"INTEREST_ID" NUMBER, 
	"USER_ID" NUMBER, 
	"PRO_ID" NUMBER
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
REM INSERTING into MD_UNIQUE.INTERESTS
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C0011209
--------------------------------------------------------

  CREATE UNIQUE INDEX "MD_UNIQUE"."SYS_C0011209" ON "MD_UNIQUE"."INTERESTS" ("INTEREST_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table INTERESTS
--------------------------------------------------------

  ALTER TABLE "MD_UNIQUE"."INTERESTS" ADD PRIMARY KEY ("INTEREST_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table INTERESTS
--------------------------------------------------------

  ALTER TABLE "MD_UNIQUE"."INTERESTS" ADD CONSTRAINT "FK_INTERESTS_USER_ID" FOREIGN KEY ("USER_ID")
	  REFERENCES "MD_UNIQUE"."USERS" ("USER_ID") ENABLE;
  ALTER TABLE "MD_UNIQUE"."INTERESTS" ADD CONSTRAINT "FK_INTERESTS_PRO_ID" FOREIGN KEY ("PRO_ID")
	  REFERENCES "MD_UNIQUE"."PRO_USER" ("PRO_ID") ENABLE;
