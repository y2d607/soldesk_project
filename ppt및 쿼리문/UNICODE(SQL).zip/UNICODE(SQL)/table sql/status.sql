--------------------------------------------------------
--  ������ ������ - ������-2��-21-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table STATUS
--------------------------------------------------------

  CREATE TABLE "MD_UNIQUE"."STATUS" 
   (	"STATUS_ID" NUMBER, 
	"USER_ID" NUMBER, 
	"PRO_ID" NUMBER, 
	"INTEREST" NUMBER(1,0), 
	"BLOCK" NUMBER(1,0)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
REM INSERTING into MD_UNIQUE.STATUS
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C0011214
--------------------------------------------------------

  CREATE UNIQUE INDEX "MD_UNIQUE"."SYS_C0011214" ON "MD_UNIQUE"."STATUS" ("STATUS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table STATUS
--------------------------------------------------------

  ALTER TABLE "MD_UNIQUE"."STATUS" ADD CHECK (interest IN (0, 1)) ENABLE;
  ALTER TABLE "MD_UNIQUE"."STATUS" ADD CHECK (block IN (0, 1)) ENABLE;
  ALTER TABLE "MD_UNIQUE"."STATUS" ADD PRIMARY KEY ("STATUS_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "USERS"  ENABLE;
